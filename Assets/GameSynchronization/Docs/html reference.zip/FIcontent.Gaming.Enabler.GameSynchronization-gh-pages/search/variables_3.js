var searchData=
[
  ['portnumber',['portNumber',['../class_f_icontent_1_1_gaming_1_1_enabler_1_1_game_synchronization_1_1_lockstep_settings.html#a8b2c38a4eac327c57bd7b3b288aca0b0',1,'FIcontent::Gaming::Enabler::GameSynchronization::LockstepSettings']]]
];
