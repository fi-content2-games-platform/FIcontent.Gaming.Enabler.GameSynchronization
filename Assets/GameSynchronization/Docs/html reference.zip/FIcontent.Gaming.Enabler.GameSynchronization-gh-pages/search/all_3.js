var searchData=
[
  ['deserialize',['Deserialize',['../class_f_icontent_1_1_gaming_1_1_enabler_1_1_game_synchronization_1_1_packets_1_1_binary_formatter_packet_serializer.html#a2f9c73cf68daf6a2d41a645763925c5a',1,'FIcontent.Gaming.Enabler.GameSynchronization.Packets.BinaryFormatterPacketSerializer.Deserialize()'],['../interface_f_icontent_1_1_gaming_1_1_enabler_1_1_game_synchronization_1_1_packets_1_1_i_packet_serializer.html#a5aaaa444b11864519daf1ff099fc5731',1,'FIcontent.Gaming.Enabler.GameSynchronization.Packets.IPacketSerializer.Deserialize()']]]
];
