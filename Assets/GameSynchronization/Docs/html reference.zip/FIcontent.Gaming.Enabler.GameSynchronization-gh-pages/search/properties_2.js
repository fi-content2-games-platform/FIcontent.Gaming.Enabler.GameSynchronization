var searchData=
[
  ['objectid',['ObjectID',['../class_f_icontent_1_1_gaming_1_1_enabler_1_1_game_synchronization_1_1_packets_1_1_actions_1_1_abstract_action.html#a82d4adf169e7f7039b160e18b56b3104',1,'FIcontent.Gaming.Enabler.GameSynchronization.Packets.Actions.AbstractAction.ObjectID()'],['../interface_f_icontent_1_1_gaming_1_1_enabler_1_1_game_synchronization_1_1_packets_1_1_actions_1_1_i_action.html#a3a93d411c6dbeac69d23cb43efda7a95',1,'FIcontent.Gaming.Enabler.GameSynchronization.Packets.Actions.IAction.ObjectID()']]]
];
